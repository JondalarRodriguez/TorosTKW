export interface Cliente{
    id: String;
    folio: String;
    RGI: String;
    Nombre: String;
    FechIngreso: String;
    Direccion: String;
    Telefono: String;
    Horario: String;
    Clase: String;
    Mensualidad: String;
}