import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-principal-admin',
  templateUrl: './principal-admin.component.html',
  styleUrls: ['./principal-admin.component.css']
})
export class PrincipalAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
