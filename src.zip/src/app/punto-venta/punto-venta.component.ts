import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-punto-venta',
  templateUrl: './punto-venta.component.html',
  styleUrls: ['./punto-venta.component.css']
})
export class PuntoVentaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
